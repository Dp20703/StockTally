import UpdateWatchlist from "./UpdateWatchlist";

const UpdateWatchlistModal = ({ setUpdateModal, watchlistId }) => {
  return (
    <div>
      <div id="modal">
        <div id="modal-content" className="text-bg-dark">
          <span
            id="close"
            className="close fs-2 text-light"
            onClick={() => setUpdateModal(false)}
          >
            &times;
          </span>
          <UpdateWatchlist
            setUpdateModal={setUpdateModal}
            watchlistId={watchlistId}
          />
        </div>
      </div>
    </div>
  );
};

export default UpdateWatchlistModal;
