import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useTrades } from "../../../context/TradeContext";
import { deleteTrade } from "./DeleteTrade";
import Swal from "sweetalert2";
import TradesTable from "./TradesTable";

const capitalize = (str) => {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

const AllTrades = ({
  setUpdateModal,
  handleTradeId,
  setCloseModal,
  showTrades,
}) => {
  const { trades, fetchTrades } = useTrades();
  const navigate = useNavigate();

  const tradesToDisplay = trades.filter((trade) => trade.status === showTrades);

  useEffect(() => {
    fetchTrades();
  }, [fetchTrades]);

  const handleDelete = async (tradeId) => {
    const result = await Swal.fire({
      title: "Delete trade?",
      text: "This trade will be permanently deleted.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      cancelButtonColor: "#1e2d3d",
      confirmButtonText: "Yes, delete it",
      background: "#0d1117",
      color: "#cbd5e1",
    });

    if (result.isConfirmed) {
      await deleteTrade(tradeId, navigate);
      await fetchTrades();
      Swal.fire({
        title: "Deleted!",
        text: "The trade has been removed.",
        icon: "success",
        background: "#0d1117",
        color: "#cbd5e1",
        confirmButtonColor: "#166534",
      });
    }
  };

  return (
    <div id="allTrades" style={styles.wrapper}>
      <div style={styles.header}>
        <h2 style={styles.title}>{capitalize(showTrades)} Trades</h2>
        <span style={styles.count}>
          {tradesToDisplay.length} record
          {tradesToDisplay.length !== 1 ? "s" : ""}
        </span>
      </div>

      <TradesTable
        trades={tradesToDisplay}
        handleTradeId={handleTradeId}
        setUpdateModal={setUpdateModal}
        setCloseModal={setCloseModal}
        handleDelete={handleDelete}
        showTrades={showTrades}
      />
    </div>
  );
};

const styles = {
  wrapper: {
    width: "100%",
  },
  header: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    marginBottom: 16,
    padding: "0 4px",
  },
  title: {
    fontSize: 16,
    fontWeight: 500,
    color: "#f0fdf4",
    margin: 0,
    letterSpacing: "-0.01em",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
  count: {
    fontSize: 10,
    color: "#cbd5e1",
    letterSpacing: "0.05em",
    fontWeight: "700",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
};

export default AllTrades;
