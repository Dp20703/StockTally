import React from "react";
import GetStockPrice from "../../../utils/GetStockPrice";

const TradeCard = ({
  trade,
  showTrades,
  handleTradeId,
  setUpdateModal,
  setCloseModal,
  handleDelete,
  styles,
}) => {
  return (
    <tr
      style={styles.tr}
      onMouseEnter={(e) => (e.currentTarget.style.background = "#1a2235")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
    >
      <td style={{ ...styles.td, fontWeight: 500, color: "#f0fdf4" }}>
        {trade.stockName}
      </td>

      <td style={{ ...styles.td, ...styles.mono, color: "#4ade80" }}>
        {trade.stockSymbol}
      </td>

      <td style={{ ...styles.td, ...styles.mono }}>₹ {trade.buyPrice}</td>

      <td style={{ ...styles.td, color: "#94a3b8" }}>
        {trade.buyDate?.split("T")[0]}
      </td>

      <td style={{ ...styles.td, ...styles.mono }}>₹ {trade.sellPrice}</td>

      <td style={{ ...styles.td, color: "#94a3b8" }}>
        {trade.sellDate?.split("T")[0]}
      </td>

      {showTrades === "open" && <td style={styles.td}>{trade.quantity}</td>}

      <td style={styles.td}>{trade.originalQuantity}</td>

      <td style={styles.td}>
        <span style={styles.badge}>{trade.type}</span>
      </td>

      <td style={styles.td}>
        <span
          style={{ ...styles.badge, background: "#1e3a5f", color: "#93c5fd" }}
        >
          {trade.entryType}
        </span>
      </td>

      <td style={styles.td}>
        <GetStockPrice
          stockSymbol={trade.stockSymbol}
          quantity={trade.quantity}
          buyPrice={trade.buyPrice}
          sellPrice={trade.sellPrice}
        />
      </td>

      {trade.status === "open" && (
        <td style={styles.td}>
          <span
            style={{
              ...styles.mono,
              color: trade.profit < 0 ? "#f87171" : "#4ade80",
            }}
          >
            {trade.profit < 0 ? "▼" : "▲"} ₹ {trade.profit?.toFixed(2)}
          </span>
        </td>
      )}

      <td style={styles.td}>
        <span
          style={{
            ...styles.mono,
            color: trade.finalProfit < 0 ? "#f87171" : "#4ade80",
          }}
        >
          {trade.finalProfit < 0 ? "▼" : "▲"} ₹ {trade.finalProfit?.toFixed(2)}
        </span>
      </td>

      <td style={styles.td}>
        <span
          style={
            trade.status === "open" ? styles.statusOpen : styles.statusClosed
          }
        >
          {trade.status}
        </span>
      </td>

      <td style={{ ...styles.td, ...styles.actions }}>
        {trade.status === "open" && (
          <>
            <button
              style={styles.btnUpdate}
              onClick={() => {
                handleTradeId(trade._id);
                setUpdateModal(true);
              }}
            >
              Update
            </button>

            <button
              style={styles.btnClose}
              onClick={() => {
                handleTradeId(trade._id);
                setCloseModal(true);
              }}
            >
              Close
            </button>
          </>
        )}

        <button
          style={styles.btnDelete}
          onClick={() => handleDelete(trade._id)}
        >
          Delete
        </button>
      </td>
    </tr>
  );
};

export default React.memo(TradeCard);
