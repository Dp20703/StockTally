import TradeCard from "./TradeCard";

const TradesTable = ({
  trades,
  setUpdateModal,
  handleTradeId,
  setCloseModal,
  handleDelete,
  showTrades,
}) => {
  return (
    <main id="tradeTable" style={styles.wrapper}>
      <table style={styles.table}>
        <thead>
          <tr>
            {[
              "Stock Name",
              "Symbol",
              "Buy Price",
              "Buy Date",
              "Sell Price",
              "Sell Date",
              ...(showTrades === "open" ? ["Cur. Qty"] : []),
              "Orig. Qty",
              "Type",
              "Entry",
              "Price & Profit",
              ...(showTrades === "open" ? ["Current P&L"] : []),
              "Final P&L",
              "Status",
              "Actions",
            ].map((h, i) => (
              <th key={i} style={styles.th}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {trades.length === 0 ? (
            <tr>
              <td colSpan={16} style={styles.empty}>
                No trades found
              </td>
            </tr>
          ) : (
            trades.map((trade) => (
              <TradeCard
                key={trade._id}
                trade={trade}
                showTrades={showTrades}
                handleTradeId={handleTradeId}
                setUpdateModal={setUpdateModal}
                setCloseModal={setCloseModal}
                handleDelete={handleDelete}
                styles={styles}
              />
            ))
          )}
        </tbody>
      </table>
    </main>
  );
};

const styles = {
  wrapper: {
    overflowX: "auto",
    borderRadius: 12,
    border: "1px solid #1e2d3d",
    background: "#0d1117",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: 13,
    color: "#cbd5e1",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
  th: {
    padding: "12px 16px",
    background: "#0f1923",
    color: "#64748b",
    fontWeight: 500,
    fontSize: 11,
    letterSpacing: "0.07em",
    textTransform: "uppercase",
    borderBottom: "1px solid #1e2d3d",
    whiteSpace: "nowrap",
    textAlign: "left",
  },
  td: {
    padding: "11px 16px",
    borderBottom: "1px solid #111827",
    whiteSpace: "nowrap",
    textAlign: "left",
    color: "#cbd5e1",
  },
  tr: {
    transition: "background .15s",
    cursor: "default",
  },
  mono: {
    fontFamily: "'Courier New', monospace",
    fontSize: 13,
  },
  badge: {
    display: "inline-block",
    padding: "2px 10px",
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 500,
    background: "#14291f",
    color: "#4ade80",
    letterSpacing: "0.04em",
  },
  statusOpen: {
    display: "inline-block",
    padding: "3px 10px",
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 500,
    background: "#14291f",
    color: "#4ade80",
    border: "1px solid #166534",
  },
  statusClosed: {
    display: "inline-block",
    padding: "3px 10px",
    borderRadius: 20,
    fontSize: 11,
    fontWeight: 500,
    background: "#2d1515",
    color: "#f87171",
    border: "1px solid #7f1d1d",
  },
  actions: {
    display: "flex",
    gap: 6,
    alignItems: "center",
  },
  btnUpdate: {
    padding: "5px 12px",
    borderRadius: 6,
    border: "1px solid #ca8a04",
    background: "transparent",
    color: "#fbbf24",
    fontSize: 12,
    cursor: "pointer",
    fontWeight: 500,
  },
  btnClose: {
    padding: "5px 12px",
    borderRadius: 6,
    border: "1px solid #334155",
    background: "transparent",
    color: "#94a3b8",
    fontSize: 12,
    cursor: "pointer",
    fontWeight: 500,
  },
  btnDelete: {
    padding: "5px 12px",
    borderRadius: 6,
    border: "1px solid #7f1d1d",
    background: "transparent",
    color: "#f87171",
    fontSize: 12,
    cursor: "pointer",
    fontWeight: 500,
  },
  empty: {
    textAlign: "center",
    padding: "32px",
    color: "#475569",
    fontSize: 14,
  },
};

export default TradesTable;
