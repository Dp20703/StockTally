import TradingViewNewsWidget from "../components/features/chart/TradingViewNewsWidget";
import Navbar from "../components/layout/Navbar";

const TopStories = () => {
  return (
    <>
      <div id="dashboard" className="overflow-x-auto">
        <Navbar />
        <TradingViewNewsWidget />
      </div>
    </>
  );
};

export default TopStories;
