import { useState } from "react";
import AllWatchlist from "../components/features/watchlist/AllWatchlist";
import CreateWatchlistModal from "../components/features/watchlist/CreateWatchlistModal";
import UpdateWatchlistModal from "../components/features/watchlist/UpdateWatchlistModal";
import Navbar from "../components/layout/Navbar";

const Watchlist = () => {
  const [watchlistId, setWatchlistId] = useState(null);
  const [modal, setModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  return (
    <>
      <div id="dashboard">
        <Navbar />

        {/* All watchlist */}
        <AllWatchlist
          setUpdateModal={setUpdateModal}
          setWatchlistId={setWatchlistId}
          setModal={setModal}
        />

        {modal && <CreateWatchlistModal setModal={setModal} />}

        {updateModal && (
          <UpdateWatchlistModal
            setUpdateModal={setUpdateModal}
            watchlistId={watchlistId}
          />
        )}
      </div>
    </>
  );
};

export default Watchlist;
