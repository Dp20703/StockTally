import Navbar from "../components/layout/Navbar";
import TradingViewWidget from "../components/features/chart/TradingViewWidget";

const ChartsPage = () => {
  return (
    <main id="dashboard" className="overflow-x-auto">
      <header>
        <Navbar />
      </header>
      
      <section>
        <TradingViewWidget />
      </section>
    </main>
  );
};

export default ChartsPage;
